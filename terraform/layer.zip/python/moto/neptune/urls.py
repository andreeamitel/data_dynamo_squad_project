"""
All calls to this service are intercepted by RDS
"""
url_bases = []  # type: ignore[var-annotated]


url_paths = {}  # type: ignore[var-annotated]
