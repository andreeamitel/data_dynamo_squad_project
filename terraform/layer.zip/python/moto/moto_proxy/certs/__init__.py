# Folder that will contain SSL certificates
# The file `req.conf.tmpl` must be kept
# Other files (*.crt) act as a cache, and will be recreated if required
